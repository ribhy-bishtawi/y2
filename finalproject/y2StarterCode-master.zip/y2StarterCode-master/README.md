# y2startercode

Starter code for the group project in WeCode y2 web development.
