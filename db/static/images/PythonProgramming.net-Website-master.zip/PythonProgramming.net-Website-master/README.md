# PythonProgramming.net-Website

This is the source code to the actual PythonProgramming.net website. This website runs with the Flask web framework for Python.

I am hosting the code here for the curious on-looker, but also seeking constructive criticism, as well as most importantly: support

PythonProgramming.net has begun as a hack-job. It functions, and it is actually very efficient at running, taking up far less processing than the wordpress version did, even with the increase of users. That said, it's got a long way to go. If you think you can help, great. 

PythonProgramming.net is all about helping people by giving free versions of what is traditionally paid, usually highly paid, material. If you think you can help in any way, great!

If you would like to contribute, see the contributing.md, or check out the issues tab. 
